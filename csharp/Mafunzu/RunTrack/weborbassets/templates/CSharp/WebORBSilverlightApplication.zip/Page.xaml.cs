using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

using Weborb.Client;

namespace $safeprojectname$
{
    public partial class Page : UserControl
    {
        private WeborbClient proxy;
        
        public Page()
        {
            InitializeComponent();
            
            proxy = new WeborbClient( App.WeborbURL, this );
            
            // a sample invocation would look like this:
            // Responder<Foo> responder = new Responder<Foo>( GotFoo, GotError );
            // proxy.Invoke( "com.foo.FooService", "getFoo", null, responder );
        }
        
         // sample responder for getFoo invocation:
         // public void GotFoo( Foo fooObject )
         // {
         //   // we got foo from Java
         // } 
         
         // sample error handler
         // public void GotError( Fault faultObject )
         // {
         //   // faultObject contains Message and Detail properties
         // } 
    }
}

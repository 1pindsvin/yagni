Imports Weborb

Namespace $safeprojectname$

Public Class SampleService

    Public Function echo(ByVal text As String) As String
        Return "Service echo: " + text
    End Function

End Class

End Namespace